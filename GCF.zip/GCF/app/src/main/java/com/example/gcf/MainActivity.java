package com.example.gcf;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.IOException;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;

    private final OkHttpClient client = new OkHttpClient();

    private File selectedImageFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button selectImageButton = findViewById(R.id.btnLaunchCamera);
        selectImageButton.setOnClickListener(view ->
                openImagePicker());


    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                try {
                    selectedImageFile = FileUtil.from(this, selectedImageUri);

                    // Now you have the selected image file, you can use it in your postImage method
                    postImage(157, selectedImageFile);
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.i("message ffor you", e.toString());
                    Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
                    // Handle exception, maybe show user a message
                }
            }
        }
    }


    public void postImage(int heightCm, File selectedImageFile) {
        if (selectedImageFile == null) {
            Toast.makeText(this, "No imag is selected", Toast.LENGTH_SHORT).show();
            // Handle case where no image is selected
            return;
        }

        // Create RequestBody instances for the image file and the height
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("image", "image.jpg", RequestBody.create(MediaType.parse("image/jpeg"), selectedImageFile))
                .addFormDataPart("height_cm", String.valueOf(heightCm))
                .build();

        // Build the request
        Request request = new Request.Builder()
                .url("http://35.192.133.120:8080/measurements")
                .post(requestBody)
                .build();
        Log.d("Request URL", request.url().toString());
        // Asynchronously execute the HTTP request
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {

                e.printStackTrace();
            }

            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                try {


                                if (response.isSuccessful()) {
                                    // Store the response body in a variable
                                    String responseData = response.body().string();

                                    // Log the response details
                                    Log.d("Response Code", String.valueOf(response.code()));
                                    Log.d("Response Body", responseData);

                                    // (e.g., update UI with the response)
                                    Toast.makeText(MainActivity.this, "Response is working", Toast.LENGTH_LONG).show();
                                    Log.e("JSON response", responseData);
                                    Toast.makeText(MainActivity.this, responseData, Toast.LENGTH_SHORT).show();
                    }
                }catch (IOException e){
                    e.printStackTrace();
                    Log.e("Response Handling Error", "Error: " + e.getMessage());
                    // You can also display a toast or update UI to inform the user about the error
                    Toast.makeText(MainActivity.this, "Error handling response", Toast.LENGTH_LONG).show();
                }
Log.i("message","work done");
            }
        });
    }
}