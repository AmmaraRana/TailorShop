package com.example.adminpanel;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.adminpanel.Customer.nav_bar;
import com.example.adminpanel.Prevalent.Prevalent;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class ConfirmFinalOrderActivity extends AppCompatActivity {
    private EditText nameedt, addressedt, cityest, stateet, postalet, customet;
    Button confirmOrderbtn, backtohome;
    String totalamount = "", sid = "", pid = "", quantity = "";
    String key;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_final_order);
        confirmOrderbtn = findViewById(R.id.confirm_final_order_btn);

        quantity = getIntent().getStringExtra("quantity");
        pid = getIntent().getStringExtra("pid");
        sid = getIntent().getStringExtra("sid");

        totalamount = getIntent().getStringExtra("Total Price");
        stateet = findViewById(R.id.stateEditText);
        postalet = findViewById(R.id.postalCodeEditText);
        customet = findViewById(R.id.custome_requirement);
        backtohome = findViewById(R.id.btnReturnToHomePage);
        nameedt = findViewById(R.id.shipment_name);
        addressedt = findViewById(R.id.shipment_address);

        cityest = findViewById(R.id.shipment_city);

        Toast.makeText(this, totalamount, Toast.LENGTH_SHORT).show();
        confirmOrderbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check();
            }

            private void check() {
                if (TextUtils.isEmpty(nameedt.getText().toString())) {
                    Toast.makeText(ConfirmFinalOrderActivity.this, "Please Fill  your name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(addressedt.getText().toString())) {
                    Toast.makeText(ConfirmFinalOrderActivity.this, "Please Fill Address", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(cityest.getText().toString())) {
                    Toast.makeText(ConfirmFinalOrderActivity.this, "Please Fill  City", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(postalet.getText().toString())) {
                    Toast.makeText(ConfirmFinalOrderActivity.this, "Please Fill  Postal Code", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(stateet.getText().toString())) {
                    Toast.makeText(ConfirmFinalOrderActivity.this, "Please Fill Up City", Toast.LENGTH_SHORT).show();
                } else {
                    confirmOrder();
                }
            }

            private void confirmOrder() {


                String saveCurrentTime, saveCurrentDate, orderkey;
                Calendar calForDate = Calendar.getInstance();
                SimpleDateFormat currentDate = new SimpleDateFormat("MM dd, yyyy");
                saveCurrentDate = currentDate.format(calForDate.getTime());

                SimpleDateFormat currentTime = new SimpleDateFormat("HH:mm:ss a");
                saveCurrentTime = currentTime.format(calForDate.getTime());

                orderkey = saveCurrentTime + saveCurrentDate;


                // Get a reference to your Firebase Realtime Database
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference orderRef = database.getReference("Orders");

String phoneedt=Prevalent.currentonlineUser.getPhone();
                HashMap<String, Object> orderMap = new HashMap<>();
                orderMap.put("name", nameedt.getText().toString());
                orderMap.put("address", addressedt.getText().toString());
                orderMap.put("city", cityest.getText().toString());
                orderMap.put("contactinfo", phoneedt.toString());
                orderMap.put("time", saveCurrentTime);
                orderMap.put("date", saveCurrentDate);
                orderMap.put("TotalAmount", totalamount);
                orderMap.put("status", "not shipped");
                orderMap.put("state", stateet.getText().toString());
                orderMap.put("customrequirement", customet.getText().toString());
                orderMap.put("postalcode", postalet.getText().toString());
                orderMap.put("sid", sid);
                orderMap.put("customer", Prevalent.currentonlineUser.getPhone());
                orderMap.put("pid", pid);
                orderMap.put("quantity", quantity);
                orderRef.child("UserOrders").child(Prevalent.currentonlineUser.getPhone()).child(orderkey).updateChildren(orderMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            FirebaseDatabase.getInstance().getReference().child("CartList")
                                    .child("UserView")
                                    .child(Prevalent.currentonlineUser.getPhone())
                                    .removeValue()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {

                                                orderRef.child("AdminOrders").child(sid).child(orderkey).updateChildren(orderMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        Toast.makeText(ConfirmFinalOrderActivity.this, "Order Request has been placed sucessfully",
                                                                Toast.LENGTH_SHORT).show();
                                                        Intent intent = new Intent(ConfirmFinalOrderActivity.this, nav_bar.class);
                                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                        startActivity(intent);
                                                        finish();
                                                    }
                                                });

//

                                            }
                                        }
                                    });
                        }
                    }
                });

            }
        });


    }


}