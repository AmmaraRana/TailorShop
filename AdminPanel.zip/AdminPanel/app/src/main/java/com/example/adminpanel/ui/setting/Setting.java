package com.example.adminpanel.ui.setting;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.adminpanel.MainActivity;
import com.example.adminpanel.Prevalent.Prevalent;
import com.example.adminpanel.ResetPasswordActivity;
import com.example.adminpanel.Customer.nav_bar;
import com.example.adminpanel.databinding.ActivitySettingBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;
import io.paperdb.Paper;

public class Setting extends AppCompatActivity {
    ActivitySettingBinding binding;

    CircleImageView profileImageView;
    private EditText fullnameEditText, addressEditText, phonenumberEditText;
    private TextView profilechangetxtbtn, closeTextbtn, saveTextbtn;
    Uri imageuri;
    private String myUrl = "";

    private String checker = "";
    private StorageReference storageprofilepictureRef;
    private StorageTask uploadtask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialization();
        Paper.init(this);
        userInfoDisplay(profileImageView, fullnameEditText, addressEditText, phonenumberEditText);
        storageprofilepictureRef = FirebaseStorage.getInstance().getReference().child("Profile pictures");
        closeTextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        saveTextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checker.equals("clicked")) {
                    usersinfosaved();
                } else {
                    updateonlyuserinfo();
                }
            }
        });

        binding.securityQuestions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Setting.this, ResetPasswordActivity.class);
                intent.putExtra("check","settings");
                startActivity(intent);
            }
        });
        binding.buttonWithImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseMessaging.getInstance().deleteToken().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Paper.book().destroy();

                        Intent intent=new Intent(new Intent(Setting.this, MainActivity.class));
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();

                    }
                });

            }
        });
        profilechangetxtbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checker = "clicked";
                CropImage.activity(imageuri)
                        .setAspectRatio(1, 1)
                        .start(Setting.this);

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            imageuri = result.getUri();
            profileImageView.setImageURI(imageuri);

        } else {
            Toast.makeText(this, "Error! Try again", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Setting.this, Setting.class));
            finish();
        }


    }

    private void updateonlyuserinfo() {

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Users");
        HashMap<String, Object> userMap = new HashMap<>();
        userMap.put("name", fullnameEditText.getText().toString());
        userMap.put("address", addressEditText.getText().toString());
        userMap.put("phone", phonenumberEditText.getText().toString());
        ref.child(Prevalent.currentonlineUser.getPhone()).updateChildren(userMap);

        startActivity(new Intent(this, nav_bar.class));
        Toast.makeText(this, "Information Updated sucessfully", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void usersinfosaved() {

        if (TextUtils.isEmpty(fullnameEditText.getText().toString())) {
            Toast.makeText(this, "User Name is mandatory", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(phonenumberEditText.getText().toString())) {
            Toast.makeText(this, "Phone Number is mandatory", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(addressEditText.getText().toString())) {
            Toast.makeText(this, "Address  is mandatory", Toast.LENGTH_SHORT).show();
        } else if (checker.equals("clicked")) {
            uploadimage();
        }
    }

    private void uploadimage() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Updating Profile");
        progressDialog.setMessage("Please wait! while we are updating your profile info");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        if (imageuri != null) {
            final StorageReference fileRef = storageprofilepictureRef.
                    child(Prevalent.currentonlineUser.getPhone() + ".jpg");
            uploadtask = fileRef.putFile(imageuri);
            uploadtask.continueWithTask(task -> {

                if (!task.isSuccessful()) {
                    throw task.getException();
                }
                return fileRef.getDownloadUrl();
            }).addOnCompleteListener((OnCompleteListener<Uri>) task -> {
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();
                    myUrl = downloadUri.toString();
                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Users");
                    HashMap<String, Object> userMap = new HashMap<>();
                    userMap.put("name", fullnameEditText.getText().toString());
                    userMap.put("address", addressEditText.getText().toString());
                    userMap.put("phone", phonenumberEditText.getText().toString());
                    userMap.put("image", myUrl);
                    ref.child(Prevalent.currentonlineUser.getPhone()).updateChildren(userMap);
                    progressDialog.dismiss();
                    startActivity(new Intent(this, nav_bar.class));
                    Toast.makeText(this, "Information Updated sucessfully", Toast.LENGTH_SHORT).show();
                    finish();

                } else {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Error Ocurred", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show();
        }
    }

    public void initialization() {
        profileImageView = binding.settingProfileImage;
        fullnameEditText = binding.settingFullName;
        addressEditText = binding.settingAddress;
        phonenumberEditText = binding.settingPhoneNumber;
        profilechangetxtbtn = binding.profileImageChange;
        closeTextbtn = binding.closeSettingBtn;
        saveTextbtn = binding.updateAccountSetting;
    }

    private void userInfoDisplay(CircleImageView profileImageView, EditText fullnameEditText,
                                 EditText addressEditText, EditText phonenumberEditText) {


        DatabaseReference UserRef = FirebaseDatabase.getInstance().getReference()
                .child("Users").child(Prevalent.currentonlineUser.getPhone());
        UserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    if (snapshot.child("image").exists()) {
                        String image = snapshot.child("image").getValue().toString();
                        String name = snapshot.child("name").getValue().toString();
                        String phone = snapshot.child("phone").getValue().toString();
                        String address = snapshot.child("address").getValue().toString();
                        Picasso.get().load(image).into(profileImageView);
                        fullnameEditText.setText(name);
                        phonenumberEditText.setText(phone);
                        addressEditText.setText(address);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}