package com.example.adminpanel.activites;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.adminpanel.Tailor.SellerAddNewProduct;
import com.example.adminpanel.databinding.ActivityLetsdoitBinding;

import java.util.ArrayList;
import java.util.List;

public class Letsdoit extends AppCompatActivity {
    ActivityLetsdoitBinding binding;
    String selectedFabric;
    CheckBox cotton, silk, wool, chiffon, khaddar, lawn, linen, viscose, organza, valvet, others;
String CategoryName,Pname,price,selectedType,selectedSex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLetsdoitBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        Pname=getIntent().getStringExtra("Pname");
//        price=getIntent().getStringExtra("price");
//        selectedType=getIntent().getStringExtra("type");
//        selectedSex=getIntent().getStringExtra("gender");


        CategoryName = getIntent().getExtras().get("Idcategory").toString();

        CheckBox[] checkBoxes = new CheckBox[]{
                binding.checkBoxCotton,
                binding.checkBoxSilk,
                binding.checkBoxWool,
                binding.checkBoxChiffon,
                binding.checkBoxKhaddar,
                binding.checkBoxLawn,
                binding.checkBoxLinen,
                binding.checkBoxViscose,
                binding.checkBoxOrganza,
                binding.checkBoxVelvet,
                binding.checkBoxOthers
        };

//        cotton = binding.checkBoxCotton;
//        silk = binding.checkBoxSilk;
//        wool = binding.checkBoxWool;
//        chiffon = binding.checkBoxChiffon;
//        khaddar = binding.checkBoxKhaddar;
//        lawn = binding.checkBoxLawn;
//        linen = binding.checkBoxLinen;
//        viscose = binding.checkBoxViscose;
//        organza = binding.checkBoxOrganza;
//        valvet = binding.checkBoxVelvet;
//        others = binding.checkBoxOthers;

//
//        List<String> selectedFabrics = new ArrayList<>();




       selectedFabric = "";


        for (CheckBox checkBox : checkBoxes) {
            checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    selectedFabric = checkBox.getText().toString();
                    // Uncheck other checkboxes
                    for (CheckBox cb : checkBoxes) {
                        if (cb != checkBox) {
                            cb.setChecked(false);
                        }
                    }
                }
            });

//        cotton.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = cotton.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = cotton.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        silk.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = silk.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = silk.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        wool.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = wool.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = wool.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        chiffon.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = chiffon.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = chiffon.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        khaddar.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = khaddar.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = khaddar.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        lawn.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = lawn.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = lawn.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        linen.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = linen.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = linen.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        viscose.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = viscose.getText().toString();
//                selectedFabrics.add(fabricText);
//            }else {
//                String fabricText = viscose.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        organza.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = organza.getText().toString();
//                selectedFabrics.add(fabricText);
//                Toast.makeText(this, selectedFabrics.toString(), Toast.LENGTH_SHORT).show();
//            }else {
//                String fabricText = organza.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        valvet.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = valvet.getText().toString();
//                selectedFabrics.add(fabricText);
//                Toast.makeText(this, selectedFabrics.toString(), Toast.LENGTH_SHORT).show();
//            }else {
//                String fabricText = valvet.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//        others.setOnCheckedChangeListener((buttonView, isChecked) -> {
//            if (isChecked) {
//                String fabricText = others.getText().toString();
//                selectedFabrics.add(fabricText);
//                Toast.makeText(this, selectedFabrics.toString(), Toast.LENGTH_SHORT).show();
//            }else {
//                String fabricText = others.getText().toString();
//                selectedFabrics.remove(fabricText);
//            }
//        });
//binding.procedNext.setOnClickListener(new View.OnClickListener() {
//    @Override
//    public void onClick(View v) {
////        Intent intent=new Intent(Letsdoit.this, SellerAddNewProduct.class);
////        intent.putExtra("fabric",selectedFabrics.toString());
////        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
////        finish();
//    }
//});

            binding.procedNext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!selectedFabric.isEmpty()) {
                        Intent intent = new Intent(Letsdoit.this, SellerAddNewProduct.class);
                        intent.putExtra("fabric", selectedFabric);


                        intent.putExtra("Idcategory", CategoryName);
//                        intent.putExtra("pName",  Pname);
//                        intent.putExtra("type", selectedType);
//                        intent.putExtra("price", price);
//                        intent.putExtra("gender", selectedSex);

                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    } else {
                        // Handle the case where no fabric is selected
                        Toast.makeText(Letsdoit.this, "Please select a fabric", Toast.LENGTH_SHORT).show();
                    }
                }
            });

binding.imageBackButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        finish();
    }
});
    }
}}