package com.example.adminpanel;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adminpanel.Buyer.CustomDialogFragment;
import com.example.adminpanel.Model.Billing;
import com.example.adminpanel.Prevalent.Prevalent;
import com.example.adminpanel.activites.BillPaymentActivity;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserOrderActivity extends AppCompatActivity implements CustomDialogFragment.DialogListener {
    RecyclerView recyclerView;
    DatabaseReference ref;
    private Billing model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_order);

        recyclerView = findViewById(R.id.confirm_recycler);
        ref = FirebaseDatabase.getInstance().getReference().child("OrderedBill")
                .child("UserView")
                .child(Prevalent.currentonlineUser.getPhone())
                .child("Bills");
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);


    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerOptions<Billing> options =
                new FirebaseRecyclerOptions.Builder<Billing>()
                        .setQuery(ref, Billing.class)
                        .build();
        FirebaseRecyclerAdapter<Billing, BillingViewHolder> adapter =
                new FirebaseRecyclerAdapter<Billing, BillingViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull BillingViewHolder holder, int position, @NonNull Billing model) {
                        if (model != null) {
                            UserOrderActivity.this.model = model;
                            holder.textAmountToPay.setText(model.getBill_amount());
                            holder.textDeliveryMinimum.setText(model.getDeliveredwithin());
                            holder.textProductName.setText(model.getProductName());

                            holder.textTapToPay.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // Create an instance of the CustomDialogFragment
                                    CustomDialogFragment dialogFragment = new CustomDialogFragment();

                                    // Set data from the current item to the dialog
                                    dialogFragment.setData(model.getProductName(), model.getBill_amount(), model.getDeliveredwithin() + "   Days"
                                            , model.getStatus(), model.getShipmentAddress(), model.getConinfo());

                                    // Show the dialog
                                    dialogFragment.show(getSupportFragmentManager(), "custom_dialog");
                                }
                            });
                        }
                    }

                    @NonNull
                    @Override
                    public BillingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.shipped_layout, parent, false);

                        return new BillingViewHolder(view);
                    }
                };
        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }


    public static class BillingViewHolder extends RecyclerView.ViewHolder {
        TextView textProductName, textDeliveryMinimum, textAmountToPay, textTapToPay;
        String amount;

        public BillingViewHolder(@NonNull View itemView) {


            super(itemView);
            textTapToPay = itemView.findViewById(R.id.textTapToPay);
            textAmountToPay = itemView.findViewById(R.id.textAmountToPay);
            textProductName = itemView.findViewById(R.id.textProductName);
            textDeliveryMinimum = itemView.findViewById(R.id.textDeliveryMinimum);

        }
    }

    @Override
    public void onOkButtonClicked() {
        // Access the Billing model for the clicked item
        Billing clickedBilling = model; // Use the model object

        // Check if the clickedBilling is not null (to avoid NullPointerException)
        if (clickedBilling != null) {
            // Extract the bill_amount from the Billing model
            String billAmount = clickedBilling.getBill_amount();

            // Create an Intent and pass the billAmount as an extra
            Intent intent = new Intent(UserOrderActivity.this, BillPaymentActivity.class);
            intent.putExtra("amount", billAmount);

            // Start the BillPaymentActivity with the intent
            startActivity(intent);
        }

    }}