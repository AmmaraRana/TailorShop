package com.example.adminpanel.activites.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.adminpanel.R;

public class CategoryActivity extends AppCompatActivity {
String catname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        catname=getIntent().getStringExtra("cat");
        Toast.makeText(this, catname, Toast.LENGTH_SHORT).show();

    }
}