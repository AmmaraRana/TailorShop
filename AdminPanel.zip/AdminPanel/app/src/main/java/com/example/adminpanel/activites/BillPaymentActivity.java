package com.example.adminpanel.activites;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.adminpanel.R;

public class BillPaymentActivity extends AppCompatActivity {
String amount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_payment);
        amount=getIntent().getStringExtra("amount");

    }
}