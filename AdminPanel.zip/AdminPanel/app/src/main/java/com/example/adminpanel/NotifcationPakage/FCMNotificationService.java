package com.example.adminpanel.NotifcationPakage;

import com.google.firebase.messaging.FirebaseMessagingService;

public class FCMNotificationService extends FirebaseMessagingService {

}
