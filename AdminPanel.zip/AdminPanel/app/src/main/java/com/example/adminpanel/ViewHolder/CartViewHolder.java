package com.example.adminpanel.ViewHolder;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.adminpanel.Interface.ItemClickListener;
import com.example.adminpanel.R;

public class CartViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public TextView txtCartname, txtcartprice, txtcartquantity;
    private ItemClickListener itemClickListener;
    public Button cartbtn;

    public CartViewHolder(View itemView) {
        super(itemView);
        cartbtn = itemView.findViewById(R.id.cart_require_btn);
        txtCartname = itemView.findViewById(R.id.cart_product_name);
        txtcartprice = itemView.findViewById(R.id.cart_product_price);
        txtcartquantity = itemView.findViewById(R.id.cart_product_quantity);
    }


    @Override
    public void onClick(View v) {
        itemClickListener.onClick(v, getAdapterPosition(), false


        );
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
}
