package com.example.adminpanel.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.adminpanel.Customer.nav_bar;
import com.example.adminpanel.R;
import com.example.adminpanel.Tailor.TailorAdapter.MultiImageAdapter;
import com.example.adminpanel.Tailor.TailorModel.ImageModel;
import com.example.adminpanel.Tailor.TailorModel.itemImageModel;

import java.util.ArrayList;

public class detailAdapter extends RecyclerView.Adapter<detailAdapter.tiViewHolder> {

    private ArrayList<ImageModel> list;
    Context context;

    public detailAdapter(ArrayList<ImageModel> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public tiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.multiple_image, parent, false);

        return new tiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull tiViewHolder holder, int position) {
        Glide.with(context).load(list.get(position).getImageUrl()).into(holder.imageView);
holder.backimage.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent=new Intent(context, nav_bar.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        context.startActivity(intent);
    }
});
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class tiViewHolder extends RecyclerView.ViewHolder{
        private ImageView imageView,backimage;
        public tiViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.getMultiIMage);
            backimage=itemView.findViewById(R.id.detailbackbtn);
        }
    }
}
