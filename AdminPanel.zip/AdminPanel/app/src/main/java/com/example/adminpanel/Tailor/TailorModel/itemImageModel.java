package com.example.adminpanel.Tailor.TailorModel;

import java.util.ArrayList;

public class itemImageModel {
    private String imageUrl;

    public itemImageModel(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
