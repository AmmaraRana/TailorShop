package com.example.adminpanel.Customer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.example.adminpanel.databinding.ActivityRegisterBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {
    ActivityRegisterBinding binding;

    private ProgressDialog loadingbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadingbar = new ProgressDialog(this);
        //setting click listener on checkbok
        binding.checkboxChecked.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    binding.Rpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    binding.cpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                }else {
                    binding.Rpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    binding.cpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
        binding.createAccountbtn.setOnClickListener(v -> {
            createAccount();
        });
    }

    private void createAccount() {
        String address=binding.Raddress.getText().toString();
        String phone = binding.Rphone.getText().toString();
        String name = binding.fullname.getText().toString();
        String password = binding.Rpassword.getText().toString();
        String cpassword = binding.cpassword.getText().toString();
        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Please enter your name... ", Toast.LENGTH_SHORT).show();
            binding.fullname.setError("Name field is empty");
            binding.fullname.requestFocus();
        } else if (TextUtils.isEmpty(phone)) {
            Toast.makeText(this, "Please enter your Phone Number... ", Toast.LENGTH_SHORT).show();
            binding.Rphone.setError("Contact Number required..");
            binding.Rphone.requestFocus();
        } else if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter your Password... ", Toast.LENGTH_SHORT).show();
            binding.Rpassword.setError("Password required..");
            binding.Rpassword.requestFocus();

        } else if (TextUtils.isEmpty(cpassword)) {
            Toast.makeText(this, "Password Confirmation required ", Toast.LENGTH_SHORT).show();
            binding.cpassword.setError("Re-type your password here..");
            binding.cpassword.requestFocus();
        } else if (!(password.equals(cpassword))) {
            Toast.makeText(RegisterActivity.this, " Password confirmation failed", Toast.LENGTH_LONG).show();
            binding.cpassword.setError("Confirm your password again");
            binding.cpassword.requestFocus();
//             make field empty
            binding.cpassword.clearComposingText();
            binding.Rpassword.clearComposingText();
        } else if (password.length() < 6) {
            Toast.makeText(RegisterActivity.this, "Password should be atleast 6_character long", Toast.LENGTH_LONG).show();
            binding.Rpassword.setError("Weak Password..");
            binding.Rpassword.requestFocus();

        }else if (!(phone.length() == 11)) {
            Toast.makeText(RegisterActivity.this, "Invalid Phone Number", Toast.LENGTH_LONG).show();
            binding.Rphone.setError("Invalid");
            binding.Rphone.requestFocus();

        }else if (TextUtils.isEmpty( address)) {
            Toast.makeText(RegisterActivity.this, "Address required", Toast.LENGTH_LONG).show();
            binding.etAddress.setError("Empty Field");
            binding.etAddress.requestFocus();

        } else {
            loadingbar.setTitle("Create Account");
            loadingbar.setMessage("Please! wait.while we are checking credientials");
            loadingbar.setCanceledOnTouchOutside(false);
            loadingbar.show();

            accountcreation(phone,password);
            ValidatePhoneNumber(name, phone, password,address);
        }


    }

    private void accountcreation(String phone, String password) {


    }

    private void ValidatePhoneNumber(String name, String phone, String password,String address) {
        final DatabaseReference RootRef = FirebaseDatabase.getInstance().getReference();
        RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!(snapshot.child("Users").child(phone).exists())) {
                    HashMap<String, Object> userDataMap = new HashMap<>();
                    userDataMap.put("phone", phone);
                    userDataMap.put("name", name);
                    userDataMap.put("password", password);
                    userDataMap.put("address",address);
                    RootRef.child("Users").child(phone).updateChildren(userDataMap)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(RegisterActivity.this, "Account Created Successfull", Toast.LENGTH_SHORT).show();
                                    loadingbar.dismiss();
                                    startActivity(new Intent(RegisterActivity.this, LoginActivity.class));

                                }
                            }).addOnFailureListener(e -> {
                                loadingbar.dismiss();
                                Toast.makeText(RegisterActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                } else {
                    Toast.makeText(RegisterActivity.this,
                            "This" + phone + "  alreasy registered for another account", Toast.LENGTH_SHORT).show();
                    loadingbar.dismiss();
                    Toast.makeText(RegisterActivity.this,
                            "Try again using another number", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

}