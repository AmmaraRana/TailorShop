package com.example.adminpanel.Tailor;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.adminpanel.R;
import com.example.adminpanel.databinding.ActivitySellerRegistrationBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class SellerRegistrationActivity extends AppCompatActivity {
    ActivitySellerRegistrationBinding binding;
    ProgressDialog progressDialog;
    String FCM;
    EditText sellername, sellerphone, selleremail, sellerpassword, sellershopaddress, bankdeatil, banknumber, shopname, sellercity;
    private FirebaseAuth mauth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySellerRegistrationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        progressDialog();

        mauth = FirebaseAuth.getInstance();
        bankdeatil = findViewById(R.id.seller_bankDetail);
        banknumber = findViewById(R.id.seller_banknumber);
        selleremail = findViewById(R.id.seller_email);
        sellername = findViewById(R.id.seller_name);
        sellerpassword = findViewById(R.id.seller_password);
        sellerphone = findViewById(R.id.seller_phone);
        sellershopaddress = findViewById(R.id.seller_address);
        sellercity = findViewById(R.id.seller_city);
        shopname = findViewById(R.id.seller_shopname);

        binding.sellerRegisterBtn.setOnClickListener(v -> {
            progressDialog.show();
            registerseller();

//            startActivity(new Intent(SellerRegistrationActivity.this,));
        });

    }

    public void progressDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Checking Credentials");
        progressDialog.setMessage("Account Registration in progress!Please wait..");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);

    }

    private void registerseller() {
        String name = sellername.getText().toString();
        String email = selleremail.getText().toString();
        String password = sellerpassword.getText().toString();
        String shopaddress = sellershopaddress.getText().toString();
        String phone = sellerphone.getText().toString();
        String bankD = bankdeatil.getText().toString();
        String bankN = banknumber.getText().toString();
        String shopn=shopname.getText().toString();
        String scity=sellercity.getText().toString();
        if ((name.isEmpty() && email.isEmpty() && password.isEmpty() && shopaddress.isEmpty() && phone.isEmpty()
                && bankN.isEmpty() && bankD.isEmpty()  && shopn.isEmpty() && scity.isEmpty())) {
            Toast.makeText(this, "Fill up form first ", Toast.LENGTH_SHORT).show();
        } else {
            mauth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                final DatabaseReference rootref = FirebaseDatabase.getInstance().getReference();


                                String sid = mauth.getCurrentUser().getUid();
                                HashMap<String, Object> sellerMap = new HashMap<>();
                                sellerMap.put("uid", sid);
                                sellerMap.put("name", name);
                                sellerMap.put("phone", phone);
                                sellerMap.put("shopaddress", shopaddress);
                                sellerMap.put("email", email);
                                sellerMap.put("password", password);
                                sellerMap.put("Account_ID", bankD);
                                sellerMap.put("Account_Number", bankN);
                                sellerMap.put("ShopName",shopn);
                                sellerMap.put("sellerCity",scity);
                                rootref.child("Tailors").child(sid).updateChildren(sellerMap)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                Toast.makeText(SellerRegistrationActivity.this, "Account Created Sucessfully", Toast.LENGTH_SHORT).show();

                                                progressDialog.dismiss();
                                                Intent intent = new Intent(SellerRegistrationActivity.this, SellerLoginActivity.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(intent);
                                                finish();

                                            }
                                        });

                            }
                        }
                    });
        }
    }


}