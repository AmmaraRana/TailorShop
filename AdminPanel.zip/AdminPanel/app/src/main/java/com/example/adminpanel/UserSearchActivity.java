package com.example.adminpanel;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adminpanel.Customer.home.ProductDetailActivity;
import com.example.adminpanel.Model.Product;
import com.example.adminpanel.ViewHolder.ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mancj.materialsearchbar.MaterialSearchBar;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Random;

public class UserSearchActivity extends AppCompatActivity {
    String selectedquery;
    MaterialSearchBar materialSearchBar;
    RecyclerView recyclerView;
    FirebaseRecyclerAdapter<Product, ViewHolder> adapter;
    ImageView backimage;
    Chip selectedChip;
    String query = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search);

        backimage = findViewById(R.id.backimage);
        backimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        recyclerView = findViewById(R.id.filter_list);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Apply chips
        TextView textView = findViewById(R.id.tv);
        ChipGroup chipGroup = findViewById(R.id.chipgroup);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Men");
        arrayList.add("Women");
        arrayList.add("Custom Stitched");
        arrayList.add("Ready to Wear");
        Random random = new Random();

        for (String s : arrayList) {
            final Chip chip = (Chip) LayoutInflater.from(this).inflate(R.layout.chip_layout, chipGroup, false);
            chip.setText(s);
            chip.setId(random.nextInt());
            chipGroup.addView(chip);

            // Set OnClickListener for each chip
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Check if there is a previously selected chip
                    if (selectedChip != null) {
                        // Unselect the previous chip
                        selectedChip.setChecked(false);
                    }

                    // Update the query string when a chip is selected
                    query = chip.getText().toString();

                    // Update UI based on the selected chip
                    textView.setText("Selected: " + query);

                    // Set the current chip as selected
                    selectedChip = chip;
                    selectedChip.setChecked(true);

                    // Apply the query with both chip and search bar
                    applyQuery();
                }
            });
        }

        // Search bar setup
        materialSearchBar = findViewById(R.id.searchBar);
        materialSearchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {
            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                query = text.toString();
                applyQuery();
            }

            @Override
            public void onButtonClicked(int buttonCode) {
            }
        });
    }

    private void applyQuery() {
        // Combine the chip query and search bar query
        String combinedQuery = query;

        // Use the combined query to fetch data
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Products");

        FirebaseRecyclerOptions<Product> options =
                new FirebaseRecyclerOptions.Builder<Product>()
                        .setQuery(reference.orderByChild("name").startAt(combinedQuery), Product.class)
                        .build();

        adapter =
                new FirebaseRecyclerAdapter<Product, ViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Product model) {
                        holder.name.setText(model.getName());
                        holder.price.setText(model.getPrice());
                        holder.description.setText(model.getDescription());
                        Picasso.get().load(model.getImage()).into(holder.productImage);
                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(UserSearchActivity.this, ProductDetailActivity.class);
                                intent.putExtra("pId", model.getpID());
                                startActivity(intent);
                            }
                        });

                    }

                    @NonNull
                    @Override
                    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_home_layout, parent, false);
                        ViewHolder holder = new ViewHolder(view);
                        return holder;
                    }
                };

        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }
}