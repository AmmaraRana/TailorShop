package com.example.adminpanel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.utils.widget.MotionButton;

import com.example.adminpanel.Customer.LoginActivity;
import com.example.adminpanel.Customer.RegisterActivity;
import com.example.adminpanel.Customer.nav_bar;
import com.example.adminpanel.Prevalent.Prevalent;
import com.example.adminpanel.Tailor.SellerLoginActivity;
import com.example.adminpanel.databinding.ActivityMainBinding;

import io.paperdb.Paper;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    private MotionButton login, signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());

        binding.textViewStartAsGuest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, nav_bar.class));
            }
        });
        setContentView(binding.getRoot());
        binding.seller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  startActivity(new Intent(MainActivity.this, SellerLoginActivity.class));
            }
        });
        login = findViewById(R.id.main_login_btn);
        signup = findViewById(R.id.main_join_now_btn);
        Paper.init(this);
        login.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));

        });
        signup.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
        });
        String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);
        String UserPasswordKey = Paper.book().read(Prevalent.UserPasswordKey);



        }
    }





