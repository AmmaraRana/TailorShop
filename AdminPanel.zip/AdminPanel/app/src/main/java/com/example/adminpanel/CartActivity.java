package com.example.adminpanel;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adminpanel.Customer.home.ProductDetailActivity;
import com.example.adminpanel.Model.Cart;
import com.example.adminpanel.Prevalent.Prevalent;
import com.example.adminpanel.ViewHolder.CartViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CartActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private Button nextProcessBtn;
    private TextView totalPrice, emptytxt;
    private int overalltotalprice = 0;
    int oneproductprice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        initialization();


    }

    private void initialization() {
        recyclerView = findViewById(R.id.cartlist);
        nextProcessBtn = findViewById(R.id.next_process_btn);
        totalPrice = findViewById(R.id.total_price);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        emptytxt = findViewById(R.id.empty);


    }

    @Override
    protected void onStart() {
        super.onStart();

        final DatabaseReference cartlistref = FirebaseDatabase.getInstance().getReference().child("CartList");

        FirebaseRecyclerOptions<Cart> options =
                new FirebaseRecyclerOptions.Builder<Cart>()
                        .setQuery(cartlistref.child("UserView")
                                        .child(Prevalent.currentonlineUser.getPhone())
                                        .child("Products")
                                , Cart.class
                        )
                        .build();
        FirebaseRecyclerAdapter<Cart, CartViewHolder> adapter = new FirebaseRecyclerAdapter<Cart, CartViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull CartViewHolder holder, int position, @NonNull Cart model) {
                holder.txtcartprice.setText(model.getPrice());
                holder.txtcartquantity.setText("Product Price:\t\t" + model.getQuantity());
                holder.txtCartname.setText("Product Name:\t" + model.getName());

                oneproductprice = ((Integer.valueOf(model.getPrice()))) * Integer.valueOf(model.getQuantity());
                overalltotalprice = overalltotalprice + oneproductprice;


                totalPrice.setText(String.valueOf(overalltotalprice));

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        CharSequence options[] = new CharSequence[]
                                {
                                        "Edit",
                                        "Remove"
                                };
                        AlertDialog.Builder builder = new AlertDialog.Builder(CartActivity.this);

                        builder.setTitle("Cart Options:");
                        builder.setItems(options
                                , new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        if (which == 0) {
                                            Intent intent = new Intent(CartActivity.this, ProductDetailActivity.class);
                                            intent.putExtra("pId", model.getpID());
                                            startActivity(intent);
                                        }
                                        if (which == 1) {
                                            cartlistref.child("UserView")
                                                    .child(Prevalent.currentonlineUser.getPhone())
                                                    .child("Product")
                                                    .child(model.getpID())
                                                    .removeValue()
                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            if (task.isSuccessful()) {
                                                                Toast.makeText(CartActivity.this, "Product Removed from CartList", Toast.LENGTH_SHORT).show();
                                                                Intent intent = new Intent(CartActivity.this, ProductDetailActivity.class);
                                                                startActivity(intent);

                                                            }
                                                        }
                                                    });

                                        }
                                    }
                                });
                        builder.show();
                    }
                });


                holder.cartbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Intent intent = new Intent(CartActivity.this, ConfirmFinalOrderActivity.class);
                        intent.putExtra("Total Price", String.valueOf(overalltotalprice));
                        intent.putExtra("sid", model.getSid());
                        intent.putExtra("pid", model.getpID());
                        intent.putExtra("quantity", model.getQuantity());
                        startActivity(intent);
                    }
                });

            }

            @NonNull
            @Override
            public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item_layout, parent, false);


                return new CartViewHolder(view);
            }
        };
        recyclerView.setAdapter(adapter);
        adapter.startListening();

    }


}