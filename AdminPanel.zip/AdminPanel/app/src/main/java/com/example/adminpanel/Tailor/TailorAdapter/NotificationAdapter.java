package com.example.adminpanel.Tailor.TailorAdapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adminpanel.R;
import com.example.adminpanel.Tailor.SellerProductDetailActivity;
import com.example.adminpanel.Tailor.TailorModel.SellerOrder;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder>{
List<SellerOrder> list;
Context context;

    public NotificationAdapter(List<SellerOrder> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public NotificationAdapter.NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_layout,parent,false);

        return new NotificationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationAdapter.NotificationViewHolder holder, int position) {
holder.pname.setText(list.get(position).getName());
holder.quantity.setText(list.get(position).getQuantity());
holder.tprice.setText(list.get(position).getPrice());

holder.itemView.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent=new Intent(context, SellerProductDetailActivity.class);
        intent.putExtra("pId",list.get(position).getpID());
        context.startActivity(intent);
    }
});
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class NotificationViewHolder extends RecyclerView.ViewHolder{
TextView pname,tprice,quantity,require;
        public NotificationViewHolder(@NonNull View itemView) {
            super(itemView);

            pname=itemView.findViewById(R.id.textProductName);
            tprice=itemView.findViewById(R.id.textPrice);
            quantity=itemView.findViewById(R.id.textQuantity);
            require=itemView.findViewById(R.id.textrequirement);
        }
    }
}
