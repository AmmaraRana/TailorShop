package com.example.adminpanel.Tailor.TailorModel;

public class SellerOrder {

    private String category,price,contact,detail,fabric,name,pID,quantity,shop,discount,sid;

    public SellerOrder(){

    }

    public SellerOrder(String category, String price, String contact, String detail,
                String fabric, String name, String pID, String quantity, String shop, String discount,String sid) {
        this.category = category;
        this.price = price;
        this.contact = contact;
        this.detail = detail;
        this.fabric = fabric;
        this.name = name;
        this.pID = pID;
        this.quantity = quantity;
        this.shop = shop;
        this.discount = discount;
        this.sid=sid;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getFabric() {
        return fabric;
    }

    public void setFabric(String fabric) {
        this.fabric = fabric;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getpID() {
        return pID;
    }

    public void setpID(String pID) {
        this.pID = pID;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getShop() {
        return shop;
    }

    public void setShop(String shop) {
        this.shop = shop;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

}
