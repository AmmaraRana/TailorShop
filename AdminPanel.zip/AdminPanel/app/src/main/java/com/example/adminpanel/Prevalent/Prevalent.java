package com.example.adminpanel.Prevalent;


import com.example.adminpanel.Model.Users;

public class Prevalent {
   public static Users currentonlineUser;

public static final  String UserPhoneKey="UserPhone";
   public static final  String UserPasswordKey="UserPassword";

}
