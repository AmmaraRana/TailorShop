package com.example.adminpanel.Model;

public class Product {

    String name, category, description, fabric, image, pID, price, sShop, size, time, date, sid;
    public String imageURL;
    String sex, Type, SellerCity, sellerAddress, sellerPhone;


    public Product() {
    }

    public Product(String name, String category, String description, String fabric,
                   String image, String pID, String price, String sShop
            ,
                   String size, String time, String date, String url,
                   String sid, String sex, String Type, String SellerCity, String sellerAddress, String sellerPhone

    ) {
        this.name = name;
        this.category = category;

        this.description = description;
        this.fabric = fabric;
        this.image = image;
        this.pID = pID;
        this.price = price;
        this.sShop
                = sShop
        ;
        this.size = size;
        this.time = time;
        this.date = date;
        this.imageURL = url;
        this.sid = sid;
        this.sex = sex;
        this.Type = Type;
        this.SellerCity = SellerCity;
        this.sellerAddress = sellerAddress;
        this.sellerPhone = sellerPhone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFabric() {
        return fabric;
    }

    public void setFabric(String fabric) {
        this.fabric = fabric;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getpID() {
        return pID;
    }

    public void setpID(String pID) {
        this.pID = pID;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getsShop() {
        return sShop;
    }

    public void setsShop(String sShop) {
        this.sShop = sShop;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getSellerCity() {
        return SellerCity;
    }

    public void setSellerCity(String sellerCity) {
        SellerCity = sellerCity;
    }

    public String getSellerAddress() {
        return sellerAddress;
    }

    public void setSellerAddress(String sellerAddress) {
        this.sellerAddress = sellerAddress;
    }

    public String getSellerPhone() {
        return sellerPhone;
    }

    public void setSellerPhone(String sellerPhone) {
        this.sellerPhone = sellerPhone;
    }
}
