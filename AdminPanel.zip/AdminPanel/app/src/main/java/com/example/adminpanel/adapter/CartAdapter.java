package com.example.adminpanel.adapter;

public class CartAdapter {


}
