package com.example.adminpanel.Tailor;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.adminpanel.Model.Product;
import com.example.adminpanel.R;
import com.example.adminpanel.Tailor.TailorAdapter.MultiImageAdapter;
import com.example.adminpanel.Tailor.TailorModel.itemImageModel;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SellerProductDetailActivity extends AppCompatActivity {
    String productID = "", state = "Normal";
    private ViewPager2 recyclerView;
    private ArrayList<itemImageModel> list;

    private MultiImageAdapter adapter;

    private DatabaseReference root = FirebaseDatabase.getInstance().getReference("Products");

    //    ImageSlider productImage;
    TextView name, price, category, contact, detail, shop, fabric,address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_product_detail);
        productID = getIntent().getStringExtra("pId");
//        productImage = findViewById(R.id.product_image_detail);
        name = findViewById(R.id.product_name_detail);
        address=findViewById(R.id.et_address);
        price = findViewById(R.id.product_price_detail);
//        shop = findViewById(R.id.product_shop_detail);
//        contact = findViewById(R.id.product_contact_detail);
        fabric = findViewById(R.id.product_fabric_detail);
        category = findViewById(R.id.product_Category_detail);
        detail = findViewById(R.id.product_description_detail);
        getProductDetail(productID);

//start writing
        recyclerView = findViewById(R.id.multiimage_recycler);


        LinearLayoutManager layoutManager =
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);

//        show item on top
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        //

        list = new ArrayList<>();
        adapter = new MultiImageAdapter(list, SellerProductDetailActivity.this);
        recyclerView.setAdapter(adapter);
        root.child(productID).child("multi:images").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear(); // Clear the list before adding new data

                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    // Make sure to retrieve the value as a String
                    String imageUrl = dataSnapshot.getValue(String.class);

                    // Add the URL to your list
                    list.add(new itemImageModel(imageUrl));
                }

                // Notify the adapter that the data has changed
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle the error
            }
        });
//        stop it

    }

    private void getProductDetail(String productID) {
        DatabaseReference productRef = FirebaseDatabase.getInstance().getReference().child("Products");
        productRef.child(productID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Product product = snapshot.getValue(Product.class);
                    name.setText(product.getName());
                    price.setText(product.getPrice());
                    category.setText(product.getCategory());
                    detail.setText(product.getDescription());
                    fabric.setText(product.getFabric());
                    address.setText(product.getSellerAddress()+","+product.getSellerCity());
//                    shop.setText(product.getShop());
//                    contact.setText(product.getContactinfo());
//                    Picasso.get().load(product.getImageURL()).into(productImage);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}