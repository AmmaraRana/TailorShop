package com.example.adminpanel.Model;

public class Category {

}
