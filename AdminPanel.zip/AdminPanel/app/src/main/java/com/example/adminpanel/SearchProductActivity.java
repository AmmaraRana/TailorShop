package com.example.adminpanel;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adminpanel.Customer.home.ProductDetailActivity;
import com.example.adminpanel.Model.Product;
import com.example.adminpanel.Tailor.ContentActivity;
import com.example.adminpanel.ViewHolder.ViewHolder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class SearchProductActivity extends AppCompatActivity {
    String query = "";
    TextView textView, noitemfound;
    private RecyclerView search_list;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_product);
        query = getIntent().getStringExtra("query");
        back = findViewById(R.id.backbtn);
        noitemfound = findViewById(R.id.no_item_found);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchProductActivity.this, ContentActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });


        textView = findViewById(R.id.search_product_name);
        textView.setText(query);
        search_list = findViewById(R.id.search_list);
        search_list.setLayoutManager(new GridLayoutManager(this, 2));
        onStart();

    }

    @Override
    protected void onStart() {
        super.onStart();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Products");

        FirebaseRecyclerOptions<Product> options =
                new FirebaseRecyclerOptions.Builder<Product>()
                        .setQuery(reference.orderByChild("name").startAt(query), Product.class)
                        .build();

        FirebaseRecyclerAdapter<Product, ViewHolder> adapter =
                new FirebaseRecyclerAdapter<Product, ViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Product model) {
                        holder.name.setText(model.getName());
                        holder.price.setText(model.getPrice());
                        holder.description.setText(model.getDescription());
                        Picasso.get().load(model.getImage()).into(holder.productImage);
                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(SearchProductActivity.this, ProductDetailActivity.class);
                                intent.putExtra("pId", model.getpID());
                                startActivity(intent);
                            }
                        });

                    }

                    @NonNull
                    @Override
                    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_home_layout, parent, false);
                        ViewHolder holder = new ViewHolder(view);
                        return holder;
                    }

                    @Override
                    public void onDataChanged() {
                        super.onDataChanged();
                        // Check if the adapter has no items and show the no item found text
                        if (getItemCount() == 0) {
                            noitemfound.setVisibility(View.VISIBLE);
                        } else {
                            noitemfound.setVisibility(View.GONE);
                        }
                    }
                };


        search_list.setAdapter(adapter);
        adapter.startListening();
    }

}