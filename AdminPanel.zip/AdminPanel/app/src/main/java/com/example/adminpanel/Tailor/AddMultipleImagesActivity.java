package com.example.adminpanel.Tailor;

import android.Manifest;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.adminpanel.R;
import com.example.adminpanel.Tailor.TailorAdapter.RecyclerAdapter;
import com.example.adminpanel.databinding.ActivityAddMultipleImagesBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class AddMultipleImagesActivity extends AppCompatActivity implements RecyclerAdapter.CountWhenItemRemoved{
    ActivityAddMultipleImagesBinding binding;
    ArrayList<Uri> uri;
    RecyclerAdapter adapter;
    RecyclerView recyclerView;
    TextView textView;
    private Uri imageuri;
    ProgressDialog progressDialog;
    StorageReference mstorage;
    Button pick,resset;

    private static final int READ_PERMISSION = 101;
    String imageUrl;
    ArrayList<String> urilist = new ArrayList<>();
    private static final int PICK_IMAGE = 1;
    String productId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddMultipleImagesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        productId = getIntent().getStringExtra("productId");

        progressDialog();

        mstorage = FirebaseStorage.getInstance().getReference("images").child("multi:images").child(productId);


        textView = binding.totalPhotos;
        resset=binding.reset;

        resset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uri.clear();
                adapter.notifyDataSetChanged();
                textView.setText("Photos(" + uri.size() + ")");
            }
        });
        recyclerView = findViewById(R.id.recyclerView_gallery_image);
        pick = findViewById(R.id.pick);
        uri = new ArrayList<>();
        adapter = new RecyclerAdapter(uri, getApplicationContext(), this);

        recyclerView.setLayoutManager(new GridLayoutManager(this,3));
        recyclerView.setAdapter(adapter);

        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(AddMultipleImagesActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(AddMultipleImagesActivity.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, READ_PERMISSION);
                    return;
                }
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }

                //  intent.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);

            }
        });

        binding.upload.setOnClickListener(v -> {
            Intent intent = new Intent(AddMultipleImagesActivity.this, ContentActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    public void progressDialog() {
        progressDialog = new ProgressDialog(this);

        progressDialog.setMessage("Setting images");

        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && null != data) {
            if (data.getClipData() != null) {
//                select multiple images
                int countOfImages = data.getClipData().getItemCount();
                for (int i = 0; i < countOfImages; i++) {

                    if (uri.size() < 100) {
                        imageuri = data.getClipData().getItemAt(i).getUri();
                        uri.add(imageuri);
                        uploadtofirebase();
                        progressDialog.show();
                    } else {
                        Toast.makeText(this, "You are not allowed to pick more then 8 images", Toast.LENGTH_SHORT).show();
                    }

                }
//                notify the adapter
                adapter.notifyDataSetChanged();
                textView.setText("Photos(" + uri.size() + ")");
            } else {
                if (uri.size() < 100) {
//                to get single image
                    imageuri = data.getData();
                    uri.add(imageuri);
                    uploadtofirebase();
                    progressDialog.show();
                } else {
                    Toast.makeText(this, "You are not allowed to pick more then 8 images", Toast.LENGTH_SHORT).show();
                }
            }
            adapter.notifyDataSetChanged();
            textView.setText("Photos(" + uri.size() + ")");
        } else {
            Toast.makeText(this, "You have not picked any image", Toast.LENGTH_SHORT).show();
        }

    }


    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void uploadtofirebase() {
        StorageReference fileReference = mstorage
                .child(System.currentTimeMillis() + "." + getFileExtension((imageuri)));

        fileReference.putFile(imageuri)
                .addOnSuccessListener(taskSnapshot -> {


                    // Get the download URL
                    fileReference.getDownloadUrl().addOnSuccessListener(uri -> {
                        // Store the download URL in the database
                        storeImageUrl(uri.toString());
                    });


                })
                .addOnFailureListener(e -> {

                    Toast.makeText(AddMultipleImagesActivity.this, "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void storeImageUrl(String toString) {

        DatabaseReference databaseReference = FirebaseDatabase.getInstance()
                .getReference("Products").child(productId).child("multi:images");
        String key = databaseReference.push().getKey();

        if (key != null) {

            databaseReference.child(key).setValue(toString)
                    .addOnSuccessListener(aVoid -> {
                        progressDialog.dismiss();
                        // Image URL stored successfully in the database
                        // You can perform additional actions here if needed
                    })
                    .addOnFailureListener(e -> {
                        progressDialog.dismiss();
                        // Handle the failure to store the image URL
                        Toast.makeText(AddMultipleImagesActivity.this, "Failed to store image URL in database", Toast.LENGTH_SHORT).show();
                    });
        }
    }


    @Override
    public void clicked(int getSize) {
        textView.setText("Photos(" + uri.size() + ")");
    }

}
